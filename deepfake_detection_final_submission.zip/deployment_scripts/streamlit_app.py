
# Streamlit Deployment Example

import streamlit as st
import numpy as np
import cv2
import tensorflow as tf

model = tf.keras.models.load_model('saved_model/deepfake_model.h5')

st.title('Deepfake Detection Streamlit App')
uploaded_file = st.file_uploader("Choose an image...")

if uploaded_file is not None:
    file_bytes = np.asarray(bytearray(uploaded_file.read()), dtype=np.uint8)
    opencv_image = cv2.imdecode(file_bytes, 1)
    opencv_image = cv2.resize(opencv_image, (128, 128))
    st.image(opencv_image, channels="BGR")
    input_img = np.expand_dims(opencv_image/255.0, axis=0)
    prediction = model.predict(input_img)[0][0]
    if prediction > 0.5:
        st.error(f"Prediction: FAKE (Confidence: {prediction*100:.2f}%)")
    else:
        st.success(f"Prediction: REAL (Confidence: {(1-prediction)*100:.2f}%)")
