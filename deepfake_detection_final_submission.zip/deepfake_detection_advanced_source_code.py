
# Step 1: Import Required Libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import cv2
import os
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.applications import Xception
from tensorflow.keras.layers import GlobalAveragePooling2D, Dense, Dropout
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score
import streamlit as st

# Step 2: Load Dataset Function
def load_dataset(real_dir, fake_dir):
    data = []
    labels = []
    for img_name in os.listdir(real_dir):
        img = cv2.imread(os.path.join(real_dir, img_name))
        img = cv2.resize(img, (128, 128))
        data.append(img)
        labels.append(0)  # Real
    for img_name in os.listdir(fake_dir):
        img = cv2.imread(os.path.join(fake_dir, img_name))
        img = cv2.resize(img, (128, 128))
        data.append(img)
        labels.append(1)  # Fake
    return np.array(data), np.array(labels)

# Step 3: Preprocessing with Data Augmentation
from tensorflow.keras.preprocessing.image import ImageDataGenerator
datagen = ImageDataGenerator(
    rescale=1./255,
    rotation_range=20,
    zoom_range=0.2,
    width_shift_range=0.2,
    height_shift_range=0.2,
    horizontal_flip=True,
    validation_split=0.15
)

# Step 4: Data Loading & Splitting
real_dir = 'dataset/real'
fake_dir = 'dataset/fake'
data, labels = load_dataset(real_dir, fake_dir)
data = data / 255.0
X_train, X_test, y_train, y_test = train_test_split(data, labels, test_size=0.2, random_state=42)

# Step 5: Model with Transfer Learning (Xception)
base_model = Xception(weights='imagenet', include_top=False, input_shape=(128,128,3))
model = Sequential([
    base_model,
    GlobalAveragePooling2D(),
    Dropout(0.5),
    Dense(1, activation='sigmoid')
])

model.compile(optimizer=tf.keras.optimizers.Adam(0.0001), loss='binary_crossentropy', metrics=['accuracy'])
history = model.fit(X_train, y_train, epochs=10, batch_size=32, validation_split=0.15)

# Step 6: Model Evaluation
y_pred = (model.predict(X_test) > 0.5).astype('int32')
print(classification_report(y_test, y_pred))
print('ROC-AUC Score:', roc_auc_score(y_test, y_pred))

# Step 7: Streamlit Deployment Example
def app():
    st.title('Deepfake Detection System')
    uploaded_file = st.file_uploader("Choose an image...")
    if uploaded_file is not None:
        file_bytes = np.asarray(bytearray(uploaded_file.read()), dtype=np.uint8)
        opencv_image = cv2.imdecode(file_bytes, 1)
        opencv_image = cv2.resize(opencv_image, (128, 128))
        st.image(opencv_image, channels="BGR")
        input_img = np.expand_dims(opencv_image/255.0, axis=0)
        prediction = model.predict(input_img)[0][0]
        if prediction > 0.5:
            st.error(f"Prediction: FAKE (Confidence: {prediction*100:.2f}%)")
        else:
            st.success(f"Prediction: REAL (Confidence: {(1-prediction)*100:.2f}%)")

# Uncomment the below line to run with Streamlit
# if __name__ == '__main__':
#     app()
