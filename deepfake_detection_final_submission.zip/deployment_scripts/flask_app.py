
# Flask Deployment Example

from flask import Flask, request, render_template
import numpy as np
import cv2
import tensorflow as tf

app = Flask(__name__)
model = tf.keras.models.load_model('saved_model/deepfake_model.h5')

@app.route('/', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        file = request.files['file']
        if file:
            img = cv2.imdecode(np.frombuffer(file.read(), np.uint8), cv2.IMREAD_COLOR)
            img = cv2.resize(img, (128, 128))
            img = np.expand_dims(img/255.0, axis=0)
            prediction = model.predict(img)[0][0]
            result = 'Fake' if prediction > 0.5 else 'Real'
            confidence = prediction if prediction > 0.5 else 1 - prediction
            return f'Prediction: {result} | Confidence: {confidence*100:.2f}%'
    return '''
    <html><body>
    <h1>Deepfake Detection Flask App</h1>
    <form method="post" enctype="multipart/form-data">
      <input type="file" name="file">
      <input type="submit">
    </form>
    </body></html>
    '''

if __name__ == '__main__':
    app.run(debug=True)
